﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ListaAlumno
{
    class NodoC
    {
        private int numero;
        private string materia;
        private string calificacion;
        private NodoC sigCalificacion;
        public int Numero
        {
            get { return numero; }
            set { numero = value; }
        }
        public string Materia
        {
            get { return materia; }
            set { materia = value; }
        }
        public string Calificacion
        {
            get { return calificacion; }
            set { calificacion = value; }
        }
        public NodoC SigCalificacion
        {
            get { return sigCalificacion; }
            set { sigCalificacion = value; }
        }
        public NodoC()
        {
            numero = 0;
            materia = "";
            calificacion = "";
            sigCalificacion = null;
        }
        public NodoC(int num, string m, string c)
        {
            numero = num;
            materia = m;
            calificacion = c;
            sigCalificacion = null;
        }
        public override string ToString()
        {
            return numero + materia + calificacion;
        }
    }
}
