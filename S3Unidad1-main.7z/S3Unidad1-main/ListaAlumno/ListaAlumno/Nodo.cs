﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ListaAlumno
{
    class Nodo
    {
        private int numero;
        private string matricula;
        private string nombre;
        private string aPaterno;
        private string aMaterno;
        private string carrera;
        private Nodo siguiente;

        public int Numero
        {
            get { return numero; }
            set { numero = value; }
        }


        public string Matricula
        {
            get { return matricula; }
            set { matricula = value; }
        }


        public string Nombre
        {
            get { return nombre; }
            set { nombre = value; }
        }


        public string APaterno
        {
            get { return aPaterno; }
            set { aPaterno = value; }
        }


        public string AMaterno
        {
            get { return aMaterno; }
            set { aMaterno = value; }
        }
        public string Carrera
        {
            get { return carrera; }
            set { carrera = value; }
        }
        public Nodo Siguiente
        {
            get { return siguiente; }
            set { siguiente = value; }
        }
        public Nodo()
        {
            numero = 0;
            matricula = "";
            nombre = "";
            aPaterno = "";
            aMaterno = "";
            carrera = "";
            siguiente = null;
        }
        public Nodo(int num, string mat, string nom, string ap, string am, string car, Lista l)
        {
            numero = num;
            matricula = mat;
            nombre = nom;
            aPaterno = ap;
            aMaterno = am;
            carrera = car;
            siguiente = null;
        }
        public override string ToString()
        {
            return numero + " - " + matricula + " - " + nombre + " - " + aPaterno + " - " + aMaterno + " - " + carrera;
        }
    }
}
